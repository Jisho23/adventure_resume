
/* And finally, start the game... */

NovelManager.start();
